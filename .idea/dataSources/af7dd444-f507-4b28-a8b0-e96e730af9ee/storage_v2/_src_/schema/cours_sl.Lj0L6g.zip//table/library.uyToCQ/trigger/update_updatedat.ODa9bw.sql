create definer = root@localhost trigger update_updatedAt
    before update
    on library
    for each row
BEGIN
	SET NEW.updatedAt = NOW();
END;


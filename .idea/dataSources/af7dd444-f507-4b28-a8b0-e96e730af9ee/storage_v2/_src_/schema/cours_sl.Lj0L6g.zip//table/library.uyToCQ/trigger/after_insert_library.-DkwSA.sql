create definer = root@localhost trigger after_insert_library
    after insert
    on library
    for each row
BEGIN
	INSERT INTO updates_history (actionName, rowId, tableName, updatedAt)
    	VALUES ("Insert", NEW.idLibrary, "library", NOW());
END;


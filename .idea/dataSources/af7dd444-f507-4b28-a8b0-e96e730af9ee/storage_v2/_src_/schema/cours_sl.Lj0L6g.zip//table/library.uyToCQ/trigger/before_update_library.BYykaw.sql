create definer = root@localhost trigger before_update_library
    before update
    on library
    for each row
BEGIN
	INSERT INTO updates_history (actionName, rowId, tableName, updatedAt)
    	VALUES ("Update", OLD.idLibrary, "library", NOW());
END;


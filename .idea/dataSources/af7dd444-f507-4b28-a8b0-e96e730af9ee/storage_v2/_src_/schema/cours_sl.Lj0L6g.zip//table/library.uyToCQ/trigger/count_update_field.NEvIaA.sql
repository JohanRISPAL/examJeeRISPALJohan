create definer = root@localhost trigger count_update_field
    before update
    on library
    for each row
BEGIN 
IF OLD.countUpdates IS NULL THEN 
	SET NEW.countUpdates = 1 ; 
ELSE 
    SET NEW.countUpdates = OLD.countUpdates + 1 ; 
    END IF; END;


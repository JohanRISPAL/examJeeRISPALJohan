create definer = root@localhost trigger before_delete_library
    before delete
    on library
    for each row
BEGIN
	INSERT INTO updates_history (actionName, rowId, tableName, updatedAt)
    	VALUES ("Delete", OLD.idLibrary, "library", NOW());
END;

